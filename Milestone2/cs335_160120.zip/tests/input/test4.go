// switch

package math;

import "fmt";

func main(){
	var k,c int = 1,0;
	switch c {
	case 0,1:
		k=2;
	case 2:
		k=3;
	default:
		k=5;
	};
};