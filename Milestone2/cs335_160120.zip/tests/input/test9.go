// Multivariadic functions

package math;
import "fmt";

var a int;

func f(a int, b int) (float,int,int)
{
	var c,d float;
	return c,a,b;
};

func main(){
	var b,d int;
	const i int = 1;
	var g float;
	g,b,d = f(b,d);

};