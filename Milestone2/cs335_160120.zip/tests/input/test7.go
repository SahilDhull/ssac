//  Type def and miscellaneous

package math;

import "fmt";

type X int;

func main(){
	var c type X;
	c = 2;
	// c = 2.0;				// Error generated
};