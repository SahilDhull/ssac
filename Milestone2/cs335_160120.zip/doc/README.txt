Source Language is GO
Implementation language is Python


Command to build and run: (considering you are in the directory cs335_160120)
cd src
make
./IR ../tests/input2/test<x>.go

where x can be from 1 to 10



The directory structure is:
1. doc			- README.txt and PDF
2. src			- lexer.py
3. tests		- 2 directories - cfg1 and input1
4. tests/input	- 10 input files in .go format for testing IR

