package math;
import "fmt";

var a int;

func f(b int) int {
	return a;
};

func main(){
	var a int = 1;
	var f,g float;
	f = g-a;
};