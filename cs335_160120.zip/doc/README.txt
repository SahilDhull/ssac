Source Language is GO
Implementation language is Python


Command to build and run: (considering you are in the directory cs335_160120)
cd src
./script.sh ../tests/<input-file>

The directory structure is:
1. doc			- README.txt and PDF
2. src			- lexer.py, parser.py, symbol.py, Makefile,
3. tests		- input files in .go format for testing IR

