#!/bin/bash

python asmgen.py $1

spim -file mips