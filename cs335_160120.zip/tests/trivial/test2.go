// arrays

package math;

import "fmt";

func main(){
	var a [2]int;
	a[0] = 1*2;
	a[1] = 2;
	var b [2]string;
	b[0] = "hello";
	b[1] = "world";
	var c [2]float;
	c[0] = 1.0;
	c[1] = 2.0;
	var d *string;
	var e [2][3][4] int;
	e[1][2][1]=1;
};
