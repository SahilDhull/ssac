//mix

package math;

import "fmt";

type X int;

func f(a int, b int) float{
	var c,d float;
	a = b;
	return c;
	// b := [5]int{1, 2, 3, 4, 5};
};

func main(){
	// var c float;
	var a float = f(23,3);
	var c int;
	if 1==0 {
		var c float;
		print "ohh";
	} else {
		print "okay\n";
	};
	// c=2;
	var k type X = 1;
	switch c {
	case 0,1:
		k=2;
	case 2:
		k=3;
	default:
		k=5;
	};
	// var sum int;
	for i:=0; i<10; i++ {
		sum:=i;
	};
};

func z(a int,b int){
	var x type X = 1;
};