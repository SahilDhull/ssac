// if-else

package math;

import "fmt";

func main(){
	var c int;
	if 1==0 {
		var c,d float;
		print %s "ohh";
	} else {
		print %s "okay\n";
	};
	// d = 1.0;           // error generating statement
};