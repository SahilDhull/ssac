package main;

func main() {
	var a float = 5.2;
	var b float = 4.3;
	var n string = "\n";
	print "a : ",a,n;
	print "b : ",b,n;
	print "a+b : ",(a+b),n;
	print "a-b : ",(a-b),n;
	print "a*b : ",(a*b),n;
	print "a/b : ",(a/b),n;
};