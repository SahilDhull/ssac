package main;


func main() {
	// a := 4;
	var a int;
	print "Enter an Element : ";
	scan a;
	if a <= 10 {
		if a <= 5 {
			print "A is <= 5\n";
		}
		else {
			print "A is >= 5\n";
		};
	}
	else {
		print "A is > 10\n";
	};
};
