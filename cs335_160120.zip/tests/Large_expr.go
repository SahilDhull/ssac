package main;

import "fmt";

func main() {
	var a int;
	a = 1*2 + 3*(4+1*5)*7/2 + 2 - 3 + 72*23+72*23+1*2 + 3*(4+1*5)*7/2-1*2 + 3*(4+1*5)*7/2;
	print a;
};
