package main;

func main() {
	a := 89;
	b := -17;
	c := a + b;
	d := -c;
	e := a - (-c) + (-(-b));
	print a;
	print "\n";
	print b;
	print "\n";
	print c;
	print "\n";
	print d;
	print "\n";
	print e;
	print "\n";	
};
