// for loop

package math;

import "fmt";

func main() {
	// var sum int;
	for i:=0; i<10; i++ {
		sum:=i;
	};
};