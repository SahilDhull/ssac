Source Language is GO
Implementation language is Python


Command to build and run: (considering you are in the directory cs335_160120)
cd src
make
./IR ../tests/input/test<x>.go

where x can be from 1 to 12



The directory structure is:
1. doc			- README.txt and PDF
2. src			- lexer.py, parser.py, symbol.py
3. tests		- 1 directory - input
4. tests/input	- 12 input files in .go format for testing IR

